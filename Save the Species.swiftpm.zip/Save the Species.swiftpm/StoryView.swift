//
//  StoryView.swift
//  Save the Species
//
//  Created by Elizaveta Petrovskaia on 06/04/23.
//

import SwiftUI



struct StoryView: View {
   
    var body: some View {
        NavigationView {
            StoryPageView(story: story, pageIndex: 0)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        StoryView()
    }
}

