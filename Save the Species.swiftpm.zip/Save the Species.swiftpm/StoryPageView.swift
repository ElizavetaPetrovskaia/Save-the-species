import SwiftUI
struct StoryPageView: View {

    let story: Story
    let pageIndex: Int

    var body: some View {
        VStack {
            ScrollView {
                Image(story[pageIndex].imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                Text(story[pageIndex].text)
                    .font(.custom("Roboto", size: 18))
            }
            ForEach(story[pageIndex].choices, id: \Choice.text) { choice in
                NavigationLink(destination: StoryPageView(story: story, pageIndex: choice.destination)) {
                    Text(choice.text)
                        .multilineTextAlignment(.leading)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                        .foregroundColor(.white)
                        .background(Color.indigo.opacity(0.80))
                        .cornerRadius(8)
                }
            }
        }
        .padding()
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(
            LinearGradient(
                gradient: Gradient(colors: [.yellow.opacity(0.65), .mint]),
                startPoint: .bottom,
                endPoint: .top
            )
            .ignoresSafeArea()
        )
    }
}

struct StoryPageView_Previews: PreviewProvider {
    static var previews: some View {
        StoryPageView(story: story, pageIndex: 0)
    }
}
