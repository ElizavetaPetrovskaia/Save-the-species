//
//  StoryModel.swift
//  Save the Species
//
//  Created by Elizaveta Petrovskaia on 06/04/23.
//

import Foundation
import UIKit
struct Story {
    
    let pages: [StoryPage]

    subscript(_ pageIndex: Int) -> StoryPage {
        return pages[pageIndex]
    }
}

struct StoryPage {
    let text: String
    let imageName: String
    let choices: [Choice]
    
    init(_ text: String,imageName: String, choices: [Choice]) {
        self.text = text
        self.imageName = imageName
        self.choices = choices
    }
}

struct Choice {
    let text: String
    let destination: Int
}

