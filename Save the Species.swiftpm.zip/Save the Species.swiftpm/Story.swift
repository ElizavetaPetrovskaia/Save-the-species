import SwiftUI

let story = Story(pages: [
    StoryPage( // 0
        """
        👋 Welcome to "Save the Species" 🌍, a game where you get to learn about the impact of human activities on our planet's biodiversity! 🐅

        Did you know that extinction of animal species is a natural process that has been happening for millions of years? 🦖

        However, things have taken a turn for the worse in recent decades, as human actions have drastically increased the rate of extinction. 😔

        Scientists are now calling this the "Sixth Mass Extinction." 💔

        It's hard to believe, but the current extinction rate is between 1,000 and 10,000 times higher than the natural! 😱

        That means we're losing so many species at an alarming rate, and it's up to us to take action and save them from disappearing forever. 💪

        Are you ready to join the mission to Save the Species? 🦜

        Let's get started! 🚀



        (Source of picture: https://www.istockphoto.com/nl/fotos/wild-animal-collage)
        """, imageName: "Biodiversity",
        choices: [
            Choice(text: "Start the game!", destination: 1 ),
            
        ]
    ),
    StoryPage( // 1
        """
        👋 You are a famous politician 🎩 with marine biologist 🐠 background in 2000 in China.

        The Baiji 🐬, also known as the Chinese river dolphin, was declared functionally extinct in 2006.

        The decline of the Baiji was primarily due to human activities such as overfishing 🎣, habitat loss 🏭, pollution 🚮, and shipping traffic 🛳️. The construction of the Three Gorges Dam on the Yangtze River, which disrupted the dolphin's habitat and prey availability 🐟, was a major factor in its decline.

        Additionally, the use of gillnets by local fishermen 🎣, which unintentionally caught and killed the dolphins 🙁, was another major threat.

        Which action 🤔 would you take?
        
                (Source of picture: https://pin.it/meBk3cd)
        """,imageName: "Baiji dolphins",
        choices: [
            Choice(text: "👉 Prioritize economic development. You argue that the Three Gorges Dam and other infrastructure projects are necessary for China's growth and that efforts to protect the Baiji are too costly and impractical. 💸👷‍♂️", destination: 2 ),
            Choice(text: "👨‍💼 You implement fishing quotas 🎣 and habitat restoration efforts 🌿 to protect the Baiji and promote its recovery. You recognize the importance of balancing economic development with conservation efforts and work to find solutions that benefit both.🐬", destination: 3 ),
            Choice(text: "You advocate for the construction of 🐟🪝 fish ladders and collaborating with 🌳👥 local communities to reduce pollution and fishing pressure.", destination: 4 ),
        ]
    ),
   
    StoryPage( // 2
        """
        Lived for over 20 million years and gone in the blink of an eye - Baiji Dolphins of Yangtze River.🐬

        🚫 You ignored the pleas of conservationists and fail to allocate funds for research or conservation efforts. The Baiji population continues to decline. Species becomes extinct because you prioritize short-term economic gains over environmental conservation.

         Game over! 😢
        

        """, imageName: "Baiji dolphins",
        choices: [
            Choice(text: "Start again", destination: 0 ),
        
        ]
    ),
   
    StoryPage( // 3
        """
        Despite your efforts, the Baiji population continued to decline, and unfortunately, the species is now considered functionally extinct. 😔 There are just a couple of them left in aquarium. The loss of this unique and important species serves as a stark reminder of the need for comprehensive conservation efforts to protect our planet's biodiversity. 🌿🌱🌍
        """, imageName: "Baiji dolphins",
        choices: [
            Choice(text: "Continue", destination: 5 ),
           
        ]
    ),
    StoryPage( // 4
        """
        The Baiji population has stabilized and is no longer on the brink of extinction. 🎉👏 Your efforts have made a real impact in protecting this important species and preserving the biodiversity of the Yangtze River! 🌿🐬
        """, imageName: "Baiji dolphins",
        choices: [
            Choice(text: "Continue", destination: 5 ),
            
        ]
    ),
    StoryPage( // 5
        """
        You are a famous non-governmental leader with a background in ecology and wildlife biology in 1987 in Europe. 🌿🦜

        The Pyrenean Ibex, also known as the bucardo or Spanish wild goat, was a subspecies of ibex that was native to the Pyrenees mountains in France and Spain, but extinct in 2000 due to human activity. 😔🐐
        
        What do you do?
        
                (Source of picture: https://wnka.co)
        """, imageName: "The Pyrenean Ibex",
        choices: [
            Choice(text: "You implement a captive breeding program that can be effective in increasing the number of individuals in a species. 🐣👨‍🔬👩‍🔬", destination: 6 ),
            Choice(text: "You decide to become one of the constructors of ski resorts as it will be very profitable. 💰🏔️ In your ski resort, you will open a zoo with Pyrenean Ibexes. 🐐🏞️", destination: 7 ),
            Choice(text: "You work with local communities to reduce hunting pressure, restoring degraded habitats, and implementing measures to mitigate the impact of climate change on the species and its habitat. 🤝🌱🐾", destination: 8 ),
    
        ]
    ),
    StoryPage( // 6
        """
        While these actions can be helpful, but they need to be part of a larger, coordinated conservation strategy that addresses the root causes of the species' decline and ensures the long-term viability of the population in the wild. 🌿🌍🦜

        Thank to you, The Pyrenean Ibex still exists, but unfortunately only in non-wild Protected area. 😔🙏
        """, imageName: "The Pyrenean Ibex",
        choices: [
            Choice(text: "Continue!", destination: 9),
          
        ]
    ),
    StoryPage( // 7
        """
        The Pyrenean Ibex, a subspecies of ibex native to the Pyrenees mountains, is extinct. 😔🐐 The decline of the Pyrenean Ibex was primarily due to human activities such as overhunting and habitat loss, with the construction of roads and ski resorts fragmenting and destroying their habitat. Climate change was another major threat, as it led to changes in vegetation patterns and altered the ibex's food sources. 🌍🏔️

        You did not manage to save Pyrenean Ibexes. 💔👎
        Game over!
        """, imageName: "The Pyrenean Ibex",

        choices: [
            Choice(text: "Start again", destination: 0),
          
        ]
    ),
   
    StoryPage( // 8
        """
        The Pyrenean Ibex have been able to recover and avoid extinction! 🎉🙌 In addition, implementing measures to mitigate the impact of climate change on the species and its habitat would have been crucial for helping other animals and people as well! 🌍🌿🐾
        """, imageName: "The Pyrenean Ibex",
        choices: [
            Choice(text: "Continue!", destination: 9), ]
    ),
    StoryPage( // 9
        """
        Imagine that you are a jornalist from local community on Caribbean island in 1935.🌍
        The Caribbean monk seal is an animal that is believed to have gone extinct in the 1950s due to human activities in the United States. The Caribbean monk seal was once found throughout the Caribbean Sea and Gulf of Mexico, but hunting for their meat, oil, and skins, as well as habitat destruction, disease, and human disturbance on their breeding grounds, caused the population to decline rapidly. 😔🌊🦭
        What would you like to do?

                 (Source of picture: https://whdh.com/news/)
        """, imageName: "The Caribbean monk seal",
        choices: [
            Choice(text: "You write about the use of oil of this animals and new private tours 💸 which were open there recently to see this animal on their breeding grounds🏝️.", destination: 10),
            Choice(text: "You use your platform as a journalist to raise awareness about the importance of protecting marine species and their habitats, and advocate for strong conservation measures to prevent further extinctions. 📰🐬🌊🌍", destination: 11),
            Choice(text: "You prioritize implementing conservation and habitat restoration efforts. 🌱🌿 This could include working with local communities to reduce hunting pressure,🌍 🦜 restoring degraded habitats, and implementing measures to mitigate the impact of climate change on the species and its habitat.👥🌡️", destination: 12),
    
        ]
    ),
    StoryPage( // 10
        """
        🌊 The Caribbean monk seal, once a common sight in the Caribbean Sea and Gulf of Mexico, was declared extinct in 2008.
        The decline of the Caribbean monk seal was primarily due to human activities such as hunting for their meat, oil, and skins, habitat destruction, disease, and human disturbance on their breeding grounds. Additionally, overfishing and climate change were major threats to the species, as they altered the availability of prey and the quality of their habitats.
        💔 You did not save them.
        🎮 Game over!
        """, imageName: "The Caribbean monk seal",
        choices: [
            Choice(text: "Start again", destination: 0),
          
        ]
    ),
    StoryPage( // 11
        """
        While these actions can be helpful, they need to be part of a larger, coordinated conservation strategy that addresses the root causes of the species' decline and ensures the long-term viability of the population in the wild. 👍 Thank to you, the Caribbean monk seal 🌊🦭, still exist, but unfortunately only in non-wild protected areas.
        """, imageName: "The Caribbean monk seal",
        choices: [
            Choice(text: "Continue!", destination: 13),
          
        ]
    ),
    StoryPage( // 12
        """
        🎉 Congratulations 🦭, you saved the Caribbean monk seal from extinction! You're a hero! 👏 And by taking steps to protect their habitat and combat climate change, you're also helping all kinds of animals 🐘🦜🐢🐋 and people 👨‍👩‍👧‍👦 thrive. Keep up the great work! 💪
        """, imageName: "The Caribbean monk seal",

        choices: [
            Choice(text: "Continue!", destination: 14),
          
        ]
    ),
    StoryPage( // 13
        """
        Even though your actions have caused species to either live in zoos or become extinct, you still tried to help them. 🤔

        There are some good things you can do to keep them safe and happy! 😊
        Would you like to know which actions would be better to take if you want to save endangered animals? 🐾
        """, imageName: "Human-Animals relationships",
        choices: [
            Choice(text: "Sure!", destination: 16 ),
            Choice(text: "No, start again!", destination: 0),
          
        ]
    ),
    StoryPage( // 14
        """
        If all people would be so careful in their choices like you, we woudnot have x number of extincted speasias of animals 🌍🐾

        You won! 🎉 Continue to know how you can still help. 💪

        (Source of picture: https://www.nhm.ac.uk/discover/polar-bear-trail.html)

        """, imageName: "Human-Animals relationships",
        choices: [
            Choice(text: "Learn more!", destination: 15),
        ]
    ),
    StoryPage( // 15
        """
               The African Elephant 🐘 is considered an endangered species due to a number of factors, including:
               
               Habitat loss: The African Elephant's natural habitat 🌳 is being rapidly destroyed and fragmented due to human activities such as logging, agriculture, and urbanization. This has reduced the elephant's range and left them with less space to roam and find food and water.
               Poaching: Elephants are hunted for their ivory tusks, which are highly valued in some cultures. This has led to a sharp decline in elephant populations in many parts of Africa.🦷
               Human-elephant conflict: As human populations continue to grow and expand into elephant habitats, there are more incidents of elephants raiding crops and causing property damage, leading to retaliation killings by farmers. 👨‍🌾
               Climate change: Climate change is altering the African Elephant's habitat by causing changes in precipitation patterns and vegetation growth, which in turn can affect food availability and migration patterns.and your efforts can help to save it! 🌍
               
               What can you do? 🤔
               -There are several things you can do to help save African Elephants, including:
               Support organizations that work to protect and conserve African Elephants.🤝
               Avoid purchasing ivory products or participating in any activity that contributes to the illegal ivory trade.🚫
               Raise awareness about the plight of African Elephants by sharing information and educating others.📢
               Visit national parks and reserves that protect African Elephants and support eco-tourism initiatives. 🌿
               Reduce your carbon footprint to help mitigate the effects of climate change, which is a major threat to African Elephants and their habitat.
               Every little action helps, and by taking these steps, you can contribute to the conservation of African Elephants and help ensure their survival.🏞️
               
               Do you want to know how to reduce your carbon footprint👣?
                       (Source of picture: https://www.discoverwildlife.com/news/)
               """,imageName: "The African Elephant",
               choices: [
                Choice(text: "Sure!", destination: 17) ]
           ),
    StoryPage( // 16
        """
        🐻🌍 Polar bears are currently considered a threatened species due to climate change and habitat loss.

        🐾 Polar bears depend on Arctic sea ice for hunting, traveling, and breeding, but the extent and duration of sea ice are decreasing as a result of global warming. This loss of sea ice is leading to a decline in polar bear populations as they are struggling to find enough food and suitable habitat.

        🌱 It is important to take action to address climate change and protect the habitat of polar bears to ensure their survival.

        There are several things you can do to help save endangered animals, including:
        🌳 Support conservation organizations that work to protect wildlife and their habitats.
        🚗 Reduce your carbon footprint by using energy-efficient appliances, driving less, and consuming less meat.
        🚫 Avoid products made from endangered animals, such as ivory or exotic animal skins.
        🎓 Educate others about the importance of conservation and the threats facing endangered species.
        💰 Volunteer your time or donate money to conservation efforts.
        ♻️ Reduce waste and recycle to help reduce pollution and habitat destruction.

        🌍 Every small action can make a difference in protecting endangered animals and their habitats.
        
        (Source of picture: https://www.nhm.ac.uk/discover/polar-bear-trail.html)
        """, imageName: "Polar bears",
        choices: [
            Choice(text: "Sure!", destination: 17) ]
    ),
    StoryPage( // 17
        """
        Here are some simple steps you can take to reduce your carbon footprint: 🌍💡🚶‍♀️

        Use energy-efficient appliances and light bulbs. 💡
        Reduce your energy consumption by turning off lights and electronics when not in use. 💡
        Use public transportation, walk, or bike instead of driving alone in a car. 🚶‍♀️🚴‍♀️🚍🚆🚇
        Eat less meat and dairy, as the production of animal products is a significant contributor to greenhouse gas emissions. 🐄🌱
        Reduce waste by recycling, composting, and using reusable products. ♻️
        Support renewable energy sources, such as solar or wind power. ☀️
        Use less water by taking shorter showers and fixing leaks. 💧
        Buy local and seasonal produce to reduce the carbon emissions associated with transportation. 🍎
        Reduce air travel or offset your carbon emissions by supporting carbon offset programs. 🛬
        By implementing these simple steps, you can make a significant impact in reducing your carbon footprint and contribute to the fight against climate change. 🌍
                (Source of picture: justenergy.com)
        """, imageName: "Carbon Footprints",
        choices: [
            Choice(text: "Continue!", destination: 18),
          
        ]
    ),
    StoryPage( // 18
        """
        Here are some simple steps you can take to reduce your carbon footprint: 🌍

        You finished the game, but life is a game too! 🎮 Do not forget to use all these advices and together we can save the species! 🐾💚
                (Source of picture: https://www.istockphoto.com/nl/fotos/wild-animal-collage)
        """,imageName: "Save these Species",
        choices: [Choice(text: "In the main page", destination: 0)
    
                 ])])
 
